# Design System Specification: Dark Signal

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Kinetic Command Center."** 

This system moves beyond the "SaaS dashboard" trope to create a high-density, mission-critical environment for high-output creators. It is inspired by radar instrumentation and premium editorial layouts. We reject the "flat" web; instead, we build with depth, using light as a functional material. The aesthetic is defined by intentional asymmetry, monospaced precision, and a "layered glass" architecture that feels both heavy with data and light in execution.

---

## 2. Color Theory & Tonal Architecture

Our palette is rooted in the deep space of `#080A12`. We do not use pure black, as it kills the depth of our glows.

### Core Palette
*   **Primary (Electric Indigo):** `#6E56CF` | Used for action, focus, and brand energy.
*   **Secondary (Neon Teal):** `#00D4AA` | Success states and positive growth metrics.
*   **Alert (Coral):** `#FF5E45` | Immediate attention and critical errors.
*   **Monetization (Amber):** `#F5A623` | Revenue-related data and warnings.
*   **Info (Sky):** `#38B2FF` | General system status and neutral data.

### The "No-Line" Rule
Standard 1px borders are strictly prohibited for sectioning. Structural definition must be achieved through:
1.  **Tonal Shifts:** Placing a `surface_container_high` card against a `surface_dim` background.
2.  **Negative Space:** Utilizing our spacing scale (`spacing.8` or `spacing.10`) to create air between functional groups.
3.  **Soft Glows:** Using a 2% opacity primary glow to define the edge of a high-priority container.

### The "Glass & Gradient" Rule
To evoke the "Command Center" feel, use **Glassmorphism** for floating elements (modals, popovers, navigation). 
*   **Formula:** `surface_container_low` at 70% opacity + `backdrop-blur(12px)`.
*   **Signature Texture:** Use a subtle linear gradient on primary CTAs: `primary_container` to `primary` (top-left to bottom-right) to give buttons a tactile, backlit quality.

---

## 3. Typography: The Editorial Edge

The hierarchy is designed to balance the raw strength of 'Bricolage Grotesque' with the technical precision of 'JetBrains Mono'.

*   **Display & Headlines (Bricolage Grotesque):** Used for "Editorial" moments—milestones, big numbers, and page headers. These should use tight letter-spacing (-0.02em) and bold weights to feel authoritative.
*   **Body & Titles (Plus Jakarta Sans):** Our workhorse. High readability for long-form creator analytics. Use `title-md` for card headers to ensure clarity.
*   **Data & Metrics (JetBrains Mono):** All numerical values, timestamps, and "system output" must use this monospaced font. It communicates accuracy and "Mission Control" authenticity.

---

## 4. Elevation, Depth & Light

We do not use shadows to "lift" objects; we use light to "illuminate" them.

### The Layering Principle (Tonal Stacking)
Depth is created by nesting surface tokens:
*   **Background:** `surface_dim` (#11131b)
*   **Section Wrap:** `surface_container_low` (#191b24)
*   **Primary Card:** `surface_container` (#1d1f28)
*   **Interactive Element:** `surface_container_highest` (#32343e)

### Ambient Shadows & Ghost Borders
*   **Shadows:** When an element must float, use a diffused glow: `box-shadow: 0 20px 40px rgba(110, 86, 207, 0.08)`. Use the color of the element (e.g., Indigo for primary buttons) as the shadow tint.
*   **Ghost Borders:** If a container needs a visual stop, use `outline_variant` at **15% opacity**. Never use a solid, opaque border.

---

## 5. Component Guidelines

### Buttons (Tactile Signals)
*   **Primary:** Gradient fill (Electric Indigo), `rounded-md`, with a subtle outer glow on hover.
*   **Secondary:** Ghost style. No background, `outline_variant` ghost border, Indigo text.
*   **Tertiary:** JetBrains Mono text only, all-caps, with a small leading signal dot (●).

### Input Fields (The Console)
*   **Style:** `surface_container_lowest` background. 
*   **Focus State:** No thick border. Instead, use a bottom-edge highlight of 2px Indigo and a subtle `surface_bright` background shift.
*   **Labels:** Always use `label-sm` in `on_surface_variant` (Secondary Text color).

### Cards & Data Lists
*   **Constraint:** Zero divider lines. 
*   **Separation:** Use `surface_container_low` for the list container and `surface_container` for the individual items. 
*   **Information Density:** In lists, use JetBrains Mono for all secondary data points to keep the "Signal" feel consistent.

### High-Density Metrics (New Component)
*   **The "Pulse" Card:** A headline metric (Display-sm) in JetBrains Mono, paired with a small sparkline using the `secondary` (Teal) color. Background should be `surface_container` with a `rounded-xl` corner.

---

## 6. Do’s and Don’ts

### Do
*   **Do** embrace asymmetry. Align a large headline to the left and a small monospaced timestamp to the far right.
*   **Do** use `JetBrains Mono` for any text that feels like "system data."
*   **Do** use the `xl` (0.75rem / 22px-equivalent) radius for large containers to soften the "tech" look.

### Don’t
*   **Don't** use white backgrounds. Ever. The lightest color allowed is `on_surface` (#e1e1ee).
*   **Don't** use standard 1px gray dividers. Use vertical spacing or tonal steps.
*   **Don't** use "drop shadows" that are black. Shadows must be tinted with the brand's Indigo or Teal to maintain the "Dark Signal" atmosphere.